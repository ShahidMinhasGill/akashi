export const lightTheme = {
  text: '#333333',
  // body: '1D2A32'
  body: 'rgba(204, 104, 50, 0.15)',
};

export const darkTheme = {
  text: '#DDDBD5',
  body:'#1D2A32',
};