import MainRoutes from "./routes/MainRoutes";


function App() {

  return (
    <div>
     <>
      {/* <Header /> for update*/}
     {/* <Header /> for update*/}
     <MainRoutes />
     </>
    </div>
  );
}

export default App;
