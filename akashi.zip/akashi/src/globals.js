export const frontend_server = 'http://127.0.0.1:3000';
export const backend_server = 'http://127.0.0.1:8000';
